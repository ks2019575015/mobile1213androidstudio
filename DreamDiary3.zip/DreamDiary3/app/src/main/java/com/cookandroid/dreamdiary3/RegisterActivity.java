package com.cookandroid.dreamdiary3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    int version = 1;
    DBHelper helper;
    SQLiteDatabase database;
    DBHelper2 helper2;
    SQLiteDatabase database2;

    EditText idEditText;
    EditText pwEditText;
    Button btnLogin;
    Button btnJoin;

    String sql;
    Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) { // 액티비티 시작시 처음으로 실행되는 생명주기!
        final EditText edit_id, edit_pw, edit_pw_re;
        final Button btn_register;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // 아이디 값 찾아주기

        idEditText = (EditText) findViewById(R.id.edit_id);
        pwEditText = (EditText) findViewById(R.id.edit_pw);
//        edit_pw_re = findViewById(R.id.edit_pw_re);

        helper = new DBHelper(RegisterActivity.this, DBHelper.tableName, null, version);
        database = helper.getWritableDatabase();
        helper2 = new DBHelper2(RegisterActivity.this, DBHelper.tableName, null, version);
        database2 = helper.getWritableDatabase();

        // 회원가입 버튼 클릭 시 수행
        btn_register = findViewById(R.id.btn_register);
        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // EditText에 현재 입력되어있는 값을 get(가져온다)해온다.
                String id = idEditText.getText().toString();
                String pw = pwEditText.getText().toString();
//                String userPW_re = edit_pw_re.getText().toString();
//                int userAge = Integer.parseInt(et_age.getText().toString());
                if (id.length() == 0 || pw.length() == 0) {
                    //아이디와 비밀번호는 필수 입력사항입니다.
                    Toast toast = Toast.makeText(RegisterActivity.this, "아이디와 비밀번호는 필수 입력사항입니다.", Toast.LENGTH_SHORT);
                    toast.show();
                    return;
                }

                sql = "SELECT id FROM "+ helper.tableName + " WHERE id = '" + id + "'";
                cursor = database.rawQuery(sql, null);
                if(cursor.getCount() != 0){
                    //존재하는 아이디입니다.
                    Toast toast = Toast.makeText(RegisterActivity.this, "존재하는 아이디입니다.", Toast.LENGTH_SHORT);
                    toast.show();
                }else{
                    helper.insertUser(database,id,pw);
                    helper2.insertDiary(database,id,null,null,null,null);


                    Toast toast = Toast.makeText(RegisterActivity.this, "가입이 완료되었습니다. 로그인을 해주세요.", Toast.LENGTH_SHORT);
                    toast.show();
                    Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }
}