package com.cookandroid.dreamdiary3;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    public static final String tableName = "Users";
    public static final String tableName2 = "Diary";


    // DBHelper 생성자로 관리할 DB 이름과 버전 정보를 받음
    public DBHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.i("tag","db 생성_db가 없을때만 최초로 실행함");
        createTable(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVer, int newVer) {
    }

    public void createTable(SQLiteDatabase db){
        String sql = "CREATE TABLE " + tableName + "(id text, pw text)";
        try {
            db.execSQL(sql);
        }catch (SQLException e){
        }

        sql = "CREATE TABLE " + tableName2 + "(id text, year integer,month integer, day integer, content text, tag text)";
        try {
            db.execSQL(sql);
        }catch (SQLException e){
        }

    }


    public void insertUser(SQLiteDatabase db, String id, String pw){
        Log.i("tag","회원가입을 했을때 실행함");
        db.beginTransaction();
        try {
            String sql = "INSERT INTO " + tableName + "(id, pw)" + "values('"+ id +"', '"+pw+"')";
            db.execSQL(sql);
            db.setTransactionSuccessful();

        }catch (Exception e){
            e.printStackTrace();
        }finally {
            db.endTransaction();
        }
    }


    public String getResult(SQLiteDatabase db, int year, int month, int day, String id) {
        db = getReadableDatabase();
        String sql = "select * from " + tableName2;
            String result = "";

            Cursor cursor = db.rawQuery(sql,null);
            result+=cursor.getString(2);


            return result;

    }

    public ArrayList SelectAllKids(){

        String SELECT_QUERY = "SELECT * FROM "+ tableName2 ;

        ArrayList kids_info = new ArrayList< String>();


        Cursor cur= getWritableDatabase().rawQuery(SELECT_QUERY, null);

        if(cur!=null && cur.moveToFirst()){

            do{

                kids_info.add(cur.getString(1));

            }while(cur.moveToNext());

        }

        return kids_info;

    }

}