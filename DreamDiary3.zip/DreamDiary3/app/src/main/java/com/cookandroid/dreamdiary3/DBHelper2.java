package com.cookandroid.dreamdiary3;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class DBHelper2 extends SQLiteOpenHelper {
    public static final String tableName = "Diary";

    // DBHelper 생성자로 관리할 DB 이름과 버전 정보를 받음
    public DBHelper2(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.i("tag","db 생성_db가 없을때만 최초로 실행함");
        createTable(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVer, int newVer) {
    }

    public void createTable(SQLiteDatabase db){
        String sql = "CREATE TABLE " + tableName + "(id text, year int,month int, day int, content text)";
        try {
            db.execSQL(sql);
        }catch (SQLException e){
        }


    }


    public void insertDiary(SQLiteDatabase db, String id, Integer year, Integer month, Integer day, String content){
        db.beginTransaction();
        try {
            String sql = "INSERT INTO " + tableName + "(id,year,month,day,content)" + "values('"+ id +"', "+year+","+month+","+day+",'"+content+"')";
            db.execSQL(sql);
            db.setTransactionSuccessful();

        }catch (Exception e){
            e.printStackTrace();
        }finally {
            db.endTransaction();
        }
    }




}
