package com.cookandroid.dreamdiary3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class CalendarActicity extends AppCompatActivity {
    int version = 1;
    DBHelper2 helper;
    SQLiteDatabase database;
    String sql;
    Cursor cursor;



    TextView textview;
    DatePicker datePicker;
    TextView viewDatePick;
    TextView textView;
    Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Intent intent = getIntent();
        String id = intent.getExtras().getString("id");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        textview = (TextView) findViewById(R.id.textView);
        viewDatePick = (TextView) findViewById(R.id.viewDatePick);
        datePicker= (DatePicker) findViewById(R.id.datePicker);
        textView = (TextView) findViewById(R.id.textview);
        button = (Button) findViewById(R.id.button);

        helper = new DBHelper2(CalendarActicity.this, DBHelper2.tableName, null, version);
        database = helper.getReadableDatabase();

        button.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CalendarActicity.this, DiaryActivity.class);
                intent.putExtra("id",id);
                intent.putExtra("year",datePicker.getYear());
                intent.putExtra("month",datePicker.getMonth()+1);
                intent.putExtra("day",datePicker.getDayOfMonth());
                startActivity(intent);
                finish();
            }
        }));

        Calendar c = Calendar.getInstance();
        int cYear = c.get(Calendar.YEAR);
        int cMonth = c.get(Calendar.MONTH);
        int cDay = c.get(Calendar.DAY_OF_MONTH);

        datePicker.init(datePicker.getYear(), datePicker.getMonth()+1, datePicker.getDayOfMonth(), new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                // 이미 선택한 날짜에 일기가 있는지 없는지 체크해야할 시간이다
                checkedDay(year, monthOfYear, dayOfMonth, id);
            }
        });


        checkedDay(cYear, cMonth, cDay,id);

    }

    private void checkedDay(int year, int monthOfYear, int dayOfMonth, String id) {
        viewDatePick.setText(year + " - " + monthOfYear + " - " + dayOfMonth);

        sql = "SELECT content FROM " + helper.tableName + " WHERE id = '" + id + "' and year = "+year+" and month = "+monthOfYear+" and day =" +dayOfMonth;
        cursor = database.rawQuery(sql, null);
        int count=0;
        String diarycontent;

        if(cursor.getCount()!=1){
            Toast toast = Toast.makeText(CalendarActicity.this,"일기가 없습니다",Toast.LENGTH_SHORT);
            toast.show();
            return;
        }else {
            while(cursor.moveToNext()){
                count++;
                diarycontent = cursor.getString(count);
                textview.setText(diarycontent);

            }




        }









    }
}