package com.cookandroid.dreamdiary3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class DiaryActivity extends AppCompatActivity {
    int version = 1;
    DBHelper2 helper;
    SQLiteDatabase database;
    String sql;
    Cursor cursor;

    Button btn1;
    Button btn2;
    EditText editText;
    TextView textView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary);

        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn3);
        editText = (EditText) findViewById(R.id.editText);
        textView = (TextView) findViewById(R.id.textView);


        Intent intent = getIntent();
        String id = intent.getExtras().getString("id");
        Integer year = intent.getExtras().getInt("year");
        Integer month = intent.getExtras().getInt("month");
        Integer day = intent.getExtras().getInt("day");

        helper = new DBHelper2(DiaryActivity.this, DBHelper2.tableName, null, version);
        database = helper.getReadableDatabase();

        textView.setText(year+"년 "+month+"월 "+day+"일");

        btn1.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DiaryActivity.this, CalendarActicity.class);
                startActivity(intent);
                finish();
            }
        }));

        btn2.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String DiaryContent;
                Intent intent = new Intent(DiaryActivity.this, CalendarActicity.class);
                DiaryContent = editText.toString();
                intent.putExtra("id",id);
                helper.insertDiary(database,id,year,month,day,DiaryContent);
                Toast toast = Toast.makeText(DiaryActivity.this,"저장완료💫",Toast.LENGTH_SHORT);
                toast.show();
                startActivity(intent);
                finish();


            }
        }));
    }
}